<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Imagenes;
use Illuminate\Support\Facades\Storage;
use App\File;
class ImagenController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $imagenes = Imagenes::all();
        return view('inicio.index',compact('imagenes'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $imagen = new Imagenes();
        $file = $request->file('imagen');
    
        $fileName = $file->getClientOriginalName();
        Storage::putFileAs(
            'public', $file, $fileName
        );
    
        Storage::setVisibility('public', $fileName);

        $imagen-> titulo = $request->titulo;
        $imagen-> archivo = $fileName;
        $imagen-> baneada = False;
        $imagen-> motivo_ban = 'ya';
        $imagen-> cuenta_user = 'tiojuaeb';
        $imagen->save();
        



    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
