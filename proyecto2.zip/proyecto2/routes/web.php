<?php

use Illuminate\Support\Facades\Route;
use App\http\Controllers\HomeController;
use App\http\Controllers\ArtistaController;
use App\http\Controllers\ImagenController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

//Route::get('/', function () {
  //  return view('welcome');
//});
Route::get('/', [HomeController::class,'index'])->name('home.index');
Route::get('/registrarse',[ArtistaController::class,'index'])->name('artista.index');
Route::post('/registrarse', [ArtistaController::class,'store'])->name('artista.store');
Route::get('/perfil', [ArtistaController::class,'perfil'])->name('artista.perfil');
Route::post('/subirImagen', [ImagenController::class,'store'])->name('imagen.store');
Route::get('/imagen', [ImagenController::class,'index'])->name('imagen.index');
