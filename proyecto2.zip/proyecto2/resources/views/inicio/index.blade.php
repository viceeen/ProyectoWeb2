@extends('template.master')
@section('contenido-principal')

<div class="container">
  <div class="row">
    @foreach($imagenes as $imagen)
      <div class="col-4">
        <div class="card mb-3 mt-3" style="width: 350px; height: 350px;">
          <img src="{{asset('storage/images/' . $imagen->archivo)}}" class="card-img-top" alt="">
          <div class="card-body">
            <h5 class="card-title">{{$imagen->titulo}}</h5>
          </div>
        </div>
      </div>
    @endforeach
  </div>
</div>
@endsection